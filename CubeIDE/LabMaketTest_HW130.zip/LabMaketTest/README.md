Программа для тестирования board stm32f103cbt6 <br>
Версия платы 1.3!!
Cхема платы и фото лежат в директории Board, сам проект разработан в CubeMX IDE.<br>
<br>
Вид меню:<br>
<img src="https://github.com/pav2000/DevBoardSTM32F103CBT/blob/main/CubeIDE/LabMaketTest/Picture/001.jpg" width="480" /> <br>
<img src="https://github.com/pav2000/DevBoardSTM32F103CBT/blob/main/CubeIDE/LabMaketTest/Picture/002.jpg" width="480" /> <br>
<img src="https://github.com/pav2000/DevBoardSTM32F103CBT/blob/main/CubeIDE/LabMaketTest/Picture/003.jpg" width="480" /> <br>
<img src="https://github.com/pav2000/DevBoardSTM32F103CBT/blob/main/CubeIDE/LabMaketTest/Picture/004.jpg" width="480" /> <br>


