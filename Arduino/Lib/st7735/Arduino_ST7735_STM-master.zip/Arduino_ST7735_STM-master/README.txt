This is fast STM32 SPI/DMA library for the ST7735 128x160 IPS display.

Optimized for the best performance for STM32. Achieved almost 36Mbps transfer via SPI/DMA.
Requires Adafruit_GFX library for Arduino.
