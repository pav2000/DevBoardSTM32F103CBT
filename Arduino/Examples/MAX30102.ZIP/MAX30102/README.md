# MAX30102
MAX30102 on Arduino Uno
and 1.8 SPI display

SpO2, heart rate and beat detection

needed liraries:

```sh
https://github.com/adafruit/Adafruit-GFX-Library

https://github.com/adafruit/Adafruit-ST7735-Library

https://github.com/catnull/Max30102Driver-For-Arduino
```

wiring:

Sensor:
```sh
MAX30102 -- Arduino

VCC -> 3.3V

GND -> GND

SCL -> A5

SDA -> A4
```
Display:
```sh
1.8 SPI -- Arduino

VCC -> 3.3V

LED+ -> 3.3V

GND -> GND

LED- -> GND

Reset -> 8

A0 -> 9

SDA -> 11

SCL -> 13

CS -> 10
```
